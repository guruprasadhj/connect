class Constants{
  // ignore: non_constant_identifier_names
  static String UsersUID      = "" ;
  // ignore: non_constant_identifier_names
  static String UsersUserName = "" ;
  // ignore: non_constant_identifier_names
  static String UsersName     = "" ;
  // ignore: non_constant_identifier_names
  static String UsersPic      = "" ;
  // ignore: non_constant_identifier_names
  static String UsersMail     = "" ;
  // ignore: non_constant_identifier_names
  static String UsersPhoneNo  = "" ;
  //static bool mode=false;
}